import React from 'react';

export default function Hero() {
  return (
    <section className="hero is-primary">
      <div className="hero-body">
        <div className="container">
          Musician App
        </div>
      </div>
    </section>
  )
}
